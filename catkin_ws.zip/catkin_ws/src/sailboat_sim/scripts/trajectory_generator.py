#!/usr/bin/env python3

import rospy
import math
from nav_msgs.msg import Path
from geometry_msgs.msg import PoseStamped

def trajectory_generator(center_x, center_y, radius, num_waypoints):
    path = Path()
    path.header.frame_id = "map"

    angle_increment = 2 * math.pi / num_waypoints

    for i in range(num_waypoints):
        angle = i * angle_increment
        pose = PoseStamped()
        pose.header.frame_id = "map"
        pose.pose.position.x = center_x + radius * math.cos(angle)
        pose.pose.position.y = center_y + radius * math.sin(angle)
        pose.pose.orientation.w = 1.0
        path.poses.append(pose)

    return path

def main():
    rospy.init_node('trajectory_generator')
    trajectory_pub = rospy.Publisher('/trajectory', Path, queue_size=10)

    rate = rospy.Rate(10)  # Publishing rate (10 Hz)

    while not rospy.is_shutdown():
        circular_trajectory = trajectory_generator(0.0, 0.0, 5.0, 100)
        trajectory_pub.publish(circular_trajectory)

        rate.sleep()  # Sleep to maintain the publishing rate

if __name__ == '__main__':
    main()


#!/usr/bin/env python3

import rospy
from nav_msgs.msg import Path
from geometry_msgs.msg import Twist
from gazebo_msgs.msg import ModelStates
import math

# Global variables
cmd_vel = Twist()  # Create a cmd_vel message instance
velocity_pub = None  # Publisher for cmd_vel
model_states = None  # To store the model states

def find_closest_point(trajectory, current_pose):
    """
    Function to find the closest point on the trajectory to the current pose.
    """
    closest_point = None
    min_distance = float('inf')

    for point in trajectory:
        # Calculate the Euclidean distance between the current pose and the trajectory point
        distance = math.sqrt((point.pose.position.x - current_pose.position.x) ** 2 +
                             (point.pose.position.y - current_pose.position.y) ** 2)
        if distance < min_distance:
            min_distance = distance
            closest_point = point

    return closest_point

def model_states_callback(msg):
    """
    Callback to update the global variable model_states with the latest model states.
    """
    global model_states
    model_states = msg  # Update the global variable with the latest model states

def trajectory_callback(msg):
    """
    Callback to handle the trajectory and calculate the desired velocity command.
    """
    global model_states

    if model_states is None or len(model_states.pose) == 0:
        rospy.logwarn("Model states not available yet.")
        return  # Wait until the model states are received

    # Ensure that there are enough models in model_states
    if len(model_states.pose) < 2:
        rospy.logwarn("Not enough models in model_states.")
        return  # Wait until the boat model is added

    # Assuming the vessel is the second model in Gazebo's model_states array (index 1)
    current_pose = model_states.pose[1]  # Change index if needed

    # Find the closest point on the trajectory
    closest_point = find_closest_point(msg.poses, current_pose)

    if closest_point is None:
        rospy.logwarn("No closest point found on the trajectory.")
        return

    # Calculate the desired heading to the closest point
    desired_heading = math.atan2(closest_point.pose.position.y - current_pose.position.y,
                                 closest_point.pose.position.x - current_pose.position.x)

    # Calculate the desired velocity (you can adjust this as needed)
    desired_velocity = 20 # Constant velocity, adjust as per your requirements

    # Update the cmd_vel message
    cmd_vel.linear.x = desired_velocity
    cmd_vel.linear.y = 0.0  # No lateral movement
    cmd_vel.linear.z = 0.0  # Prevent vertical movement (this stops the boat from sinking)

    # Current orientation of the boat
    current_orientation = 2 * math.atan2(current_pose.orientation.z, current_pose.orientation.w)
    cmd_vel.angular.z = desired_heading - current_orientation

    # Normalize angular difference
    cmd_vel.angular.z = (cmd_vel.angular.z + math.pi) % (2 * math.pi) - math.pi

    # Publish the desired velocity
    velocity_pub.publish(cmd_vel)
    rospy.loginfo(f"Publishing cmd_vel: linear.x={cmd_vel.linear.x}, angular.z={cmd_vel.angular.z}")

def main():
    global velocity_pub

    rospy.init_node('path_follower')

    rospy.loginfo("Path follower node started.")

    # Publisher for the velocity command
    velocity_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)

    # Subscribers for trajectory and model states
    rospy.Subscriber('/trajectory', Path, trajectory_callback)
    rospy.Subscriber('/gazebo/model_states', ModelStates, model_states_callback)

    rospy.spin()  # Keep the node running

if __name__ == '__main__':
    main()



